<header>
    <div class="container">
        <h1>Магазин оборудования</h1>
        <nav>
            <ul>
                <li><a href="index.php">Главная</a></li>
                <li><a href="catalog.php">Каталог</a></li>
                <li><a href="cart.php">Корзина</a></li>
                <li><a href="checkout.php">Оформление заказа</a></li>
                <li><a href="user.php">Личный кабинет</a></li>
                <li><a href="admin.php">Админ панель</a></li>
            </ul>
        </nav>
    </div>
</header>

<?php
session_start();

// Простая проверка авторизации
$isAdmin = $_SESSION['isAdmin'] ?? false;

if (!$isAdmin) {
    die('Доступ запрещен. Только для администраторов.');
}

// Пример массивов (замените на подключение к базе данных)
$products = [
    ['id' => 1, 'name' => 'Камера Sony Alpha', 'price' => 120000, 'image' => 'images/camera.jpg'],
    ['id' => 2, 'name' => 'Микрофон Rode NT-USB', 'price' => 15000, 'image' => 'images/microphone.jpg'],
];

$users = [
    ['id' => 1, 'name' => 'Иван Иванов', 'email' => 'ivanov@example.com'],
    ['id' => 2, 'name' => 'Анна Смирнова', 'email' => 'anna@example.com'],
];

$orders = [
    ['id' => 1, 'user' => 'Иван Иванов', 'total' => 15000, 'status' => 'В обработке'],
    ['id' => 2, 'user' => 'Анна Смирнова', 'total' => 120000, 'status' => 'Доставлен'],
];

// Обработка действий администратора
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action === 'add_product') {
            // Добавление товара
            $products[] = [
                'id' => count($products) + 1,
                'name' => $_POST['name'],
                'price' => $_POST['price'],
                'image' => $_POST['image'],
            ];
        } elseif ($action === 'delete_product') {
            // Удаление товара
            $idToDelete = $_POST['id'];
            $products = array_filter($products, fn($p) => $p['id'] !== (int)$idToDelete);
        } elseif ($action === 'update_order') {
            // Обновление статуса заказа
            $orderId = $_POST['id'];
            foreach ($orders as &$order) {
                if ($order['id'] === (int)$orderId) {
                    $order['status'] = $_POST['status'];
                    break;
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Административная панель</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Административная панель</h1>
    </header>

    <main>
        <!-- Общая статистика -->
        <section>
            <h2>Статистика</h2>
            <p>Товары: <?= count($products) ?></p>
            <p>Пользователи: <?= count($users) ?></p>
            <p>Заказы: <?= count($orders) ?></p>
        </section>

        <!-- Управление товарами -->
        <section>
            <h2>Управление товарами</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Название</th>
                        <th>Цена</th>
                        <th>Изображение</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?= $product['id'] ?></td>
                            <td><?= htmlspecialchars($product['name']) ?></td>
                            <td><?= htmlspecialchars($product['price']) ?> ₽</td>
                            <td><img src="<?= htmlspecialchars($product['image']) ?>" alt="Товар" width="50"></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="id" value="<?= $product['id'] ?>">
                                    <input type="hidden" name="action" value="delete_product">
                                    <button type="submit">Удалить</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <h3>Добавить новый товар</h3>
            <form method="POST">
                <label>Название:</label>
                <input type="text" name="name" required>
                <label>Цена:</label>
                <input type="number" name="price" required>
                <label>Ссылка на изображение:</label>
                <input type="text" name="image" required>
                <input type="hidden" name="action" value="add_product">
                <button type="submit">Добавить</button>
            </form>
        </section>

        <!-- Управление пользователями -->
        <section>
            <h2>Управление пользователями</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Имя</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?= $user['id'] ?></td>
                            <td><?= htmlspecialchars($user['name']) ?></td>
                            <td><?= htmlspecialchars($user['email']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <!-- Управление заказами -->
        <section>
            <h2>Управление заказами</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Пользователь</th>
                        <th>Сумма</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= $order['id'] ?></td>
                            <td><?= htmlspecialchars($order['user']) ?></td>
                            <td><?= htmlspecialchars($order['total']) ?> ₽</td>
                            <td><?= htmlspecialchars($order['status']) ?></td>
                            <td>
                                <form method="POST">
                                    <input type="hidden" name="id" value="<?= $order['id'] ?>">
                                    <label>Изменить статус:</label>
                                    <select name="status" required>
                                        <option value="В обработке">В обработке</option>
                                        <option value="Доставлен">Доставлен</option>
                                        <option value="Отменен">Отменен</option>
                                    </select>
                                    <input type="hidden" name="action" value="update_order">
                                    <button type="submit">Обновить</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>

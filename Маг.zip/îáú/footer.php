<footer>
    <div class="footer-container">
        <p>&copy; <?php echo date('Y'); ?> Магазин оборудования для видеоблогеров. Все права защищены.</p>
        <nav class="footer-nav">
            <a href="index.php">Главная</a>
            <a href="catalog.php">Каталог</a>
            <a href="contact.php">Контакты</a>
        </nav>
    </div>
</footer>

</body>
</html>
